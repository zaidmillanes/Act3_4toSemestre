// src/App.js
import React, { useState } from "react";
import "./App.css";
import productos from "./data";
import Carrito from "./Carrito"; // Importa el componente Carrito

function App() {
    const [carrito, setCarrito] = useState([]);
    const [mostrarCarrito, setMostrarCarrito] = useState(false);

  
    const agregarAlCarrito = (item, cantidad) => {
        const itemEnCarrito = carrito.find((cartItem) => cartItem.id === item.id);

        if (itemEnCarrito) {
            setCarrito(
                carrito.map((cartItem) =>
                    cartItem.id === item.id
                        ? { ...cartItem, cantidad: cartItem.cantidad + cantidad }
                        : cartItem
                )
            );
        } else {
            setCarrito([...carrito, { ...item, cantidad }]);
        }
    };

    return (
        <div className="app">
            <h1>Tienda de Abarrotes</h1>
            <button className="buy-button" onClick={() => setMostrarCarrito(true)}>
                Ver Carrito ({carrito.reduce((total, item) => total + item.cantidad, 0)})
            </button>
            <main>
                <div className="product-list">
                    {productos.map((producto) => (
                        <Producto
                            key={producto.id}
                            producto={producto}
                            agregarAlCarrito={agregarAlCarrito}
                        />
                    ))}
                </div>
            </main>
            {mostrarCarrito && (
                <Carrito
                    carrito={carrito}
                    setCarrito={setCarrito}
                    setMostrarCarrito={setMostrarCarrito}
                />
            )}
        </div>
    );
}

const Producto = ({ producto, agregarAlCarrito }) => {
    const [cantidad, setCantidad] = useState(1);

    return (
        <div className="item">
            <img
                src={producto.imagen}
                alt={producto.titulo}
                className="item-image"
            />
            <h2 className="item-title">{producto.titulo}</h2>
            <p className="item-description">{producto.descripcion}</p>
            <p className="item-price">${producto.precio}</p>
            <div className="quantity-selector">
                <label>
                    Cantidad:
                    <input
                        type="number"
                        min="1"
                        value={cantidad}
                        onChange={(e) => setCantidad(Number(e.target.value))}
                        className="quantity-input"
                    />
                </label>
            </div>
            <button
                className="buy-button"
                onClick={() => agregarAlCarrito(producto, cantidad)}
            >
                Comprar
            </button>
        </div>
    );
};
export default App;