// src/data.js
const productos = [
  {
    id: 1,
    titulo: "Arroz Blanco",
        imagen: "https://images.pexels.com/photos/7232901/pexels-photo-7232901.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    descripcion: "Arroz blanco de grano largo, ideal para acompanar cualquier platillo.",
    precio: 25.00
  },
  {
    id: 2,
    titulo: "Frijoles Negros",
      imagen: "https://images.pexels.com/photos/6316677/pexels-photo-6316677.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    descripcion: "Frijoles negros cocidos, ricos en prote�nas y perfectos para tacos o sopas.",
    precio: 30.00
  },
  {
    id: 3,
    titulo: "Aceite de Girasol",
      imagen: "https://media.istockphoto.com/id/164299645/photo/cooking-oil.jpg?s=1024x1024&w=is&k=20&c=6VASccvA0zlWR0W73CkkIfcJfySN5MNfnKgUDfQ8Y2g=",
    descripcion: "Aceite de girasol 100% natural, ideal para freir o cocinar.",
    precio: 45.00
  },
  {
    id: 4,
    titulo: "Pan",
      imagen: "https://images.pexels.com/photos/209211/pexels-photo-209211.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    descripcion: "Pan recien horneado perfecto para la mananas.",
    precio: 20.00
  },
  {
    id: 5,
    titulo: "Azucar",
      imagen: "https://images.pexels.com/photos/11477544/pexels-photo-11477544.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    descripcion: "Azucar de alta calidad, perfecta para postres o cafe.",
    precio: 35.00
  },
  {
    id: 6,
    titulo: "Sal de Mesa",
      imagen: "https://images.pexels.com/photos/6682957/pexels-photo-6682957.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1",
    descripcion: "Sal de mesa fina, esencial en cualquier cocina.",
    precio: 15.00
  },
  {
    id: 7,
    titulo: "Pasta de Diente de Leon",
      imagen: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTltYEqgYWni66ZHuMBcJNOSYR-4Y0uMKu16g&s",
    descripcion: "Pasta de diente de leon, ideal para una dieta saludable.",
    precio: 50.00
  },
  {
    id: 8,
    titulo: "Atun en Agua",
      imagen: "https://hebmx.vtexassets.com/arquivos/ids/583949-800-800?v=638497714035730000&width=800&height=800&aspect=true",
    descripcion: "Atun en agua, bajo en grasa y rico en proteinas.",
    precio: 40.00
  },
  {
    id: 9,
    titulo: "Cafe Molido",
      imagen: "https://perfectdailygrind.com/es/wp-content/uploads/sites/2/2020/04/photo-1510776537653-6d0da167186c-1024x683.jpeg",
    descripcion: "Cafe molido 100% arabigo, perfecto para empezar el dia.",
    precio: 60.00
  },
  {
    id: 10,
    titulo: "Galletas de Avena",
      imagen: "https://m.media-amazon.com/images/I/61+gqsfxI2L._AC_UF1000,1000_QL80_.jpg",
    descripcion: "Galletas de avena horneadas, ideales para un snack saludable.",
    precio: 28.00
  }
];

export default productos;