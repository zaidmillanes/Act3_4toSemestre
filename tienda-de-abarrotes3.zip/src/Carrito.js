// src/Carrito.js
import React from "react";

const Carrito = ({ carrito, setCarrito, setMostrarCarrito }) => {
    const eliminarDelCarrito = (id) => {
        setCarrito(carrito.filter((item) => item.id !== id));
    };

    // Calcular el precio total del carrito
    const calcularTotal = () => {
        return carrito.reduce((total, item) => total + item.precio * item.cantidad, 0);
    };

    return (
        <div className="item" style={{ position: "fixed", top: "20px", right: "20px", width: "300px" }}>
            <h2>Carrito de Compras</h2>
            <button className="cancel-button" onClick={() => setMostrarCarrito(false)}>
                Cerrar
            </button>
            {carrito.length === 0 ? (
                <p>No hay articulos en el carrito.</p>
            ) : (
                <>
                    <ul>
                        {carrito.map((item) => (
                            <li key={item.id}>
                                <span>
                                    {item.titulo} - Cantidad: {item.cantidad} - Precio Unitario: ${item.precio}
                                </span>
                                <button
                                    className="cancel-button"
                                    onClick={() => eliminarDelCarrito(item.id)}
                                >
                                    Eliminar
                                </button>
                            </li>
                        ))}
                    </ul>
                    <h3>Total: ${calcularTotal()}</h3>
                </>
            )}
        </div>
    );
};

export default Carrito;